package com.example.news;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CrearBaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_base);

        DbHelper dbHelper = new DbHelper(CrearBaseActivity.this);

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        if (db != null) {
            Toast.makeText(CrearBaseActivity.this, "Base de Datos Creada", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(CrearBaseActivity.this, "Error al crear DataBase", Toast.LENGTH_SHORT).show();
        }
    }
}

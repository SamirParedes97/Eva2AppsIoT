package com.example.news;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

public class Subscriber extends DbHelper {

    Context context;

    private int id;
    private String nombre;
    private String correo;

    public Subscriber(@Nullable Context context) {
        super(context);

        this.context = context;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }


    public long insertSub(String nombre, String correo) {
        long id = 0;

        try {

            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();

            values.put("nombre", nombre);
            values.put("correo", correo);

            id = db.insert(TABLE_SUBS, null, values);

        } catch (Exception ex) {
            ex.toString();
        }

        return id;

    }





}

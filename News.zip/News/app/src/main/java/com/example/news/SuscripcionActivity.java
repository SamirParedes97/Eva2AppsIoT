package com.example.news;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class SuscripcionActivity extends AppCompatActivity {

    EditText nombreTxt, correoTxt;
    CheckBox chkEco, chkPol, chkCul, chkDep, chkFar;
    Button btnSuscripcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suscripcion);

        nombreTxt = findViewById(R.id.nombreTxt);
        correoTxt = findViewById(R.id.correoTxt);

        chkEco = findViewById(R.id.chkEco);
        chkPol = findViewById(R.id.chkPol);
        chkCul = findViewById(R.id.chkCul);
        chkDep = findViewById(R.id.chkDep);
        chkFar = findViewById(R.id.chkFar);

        btnSuscripcion = findViewById(R.id.btnSuscripcion);

        btnSuscripcion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Subscriber sub = new Subscriber(SuscripcionActivity.this);
                long id = sub.insertSub(nombreTxt.getText().toString(),correoTxt.getText().toString());
                if (id > 0) {
                    Toast.makeText(SuscripcionActivity.this,"SE HA SUSCRITO CON ÉXITO",Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SuscripcionActivity.this,"SE HA SUSCRITO CON ÉXITO",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}